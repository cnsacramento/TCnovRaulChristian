<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facturas</title>
    <link rel='stylesheet' type='text/css' media='screen' href="<?php echo e(asset('css/general.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/crud.css')); ?>">
    <meta name="description" content="Métodos para realizar el CRUD sobre facturas">
</head>

<body>
    <header>
        <nav>
            <a href="/" class="nav-link">Volver</a>
        </nav>
    </header>

    <div class="crud">

  <article>

   <h3 class="text-center">Eliminar factura</h3>
   <form action="/facturas/eliminar" method="post">
    <?php echo csrf_field(); ?>
    <label for=""> <span>*ID:</span> <input class="text-end" type="number"
     name="id" id="id" value="<?php if(isset($factura)): ?><?php echo e($factura->id); ?><?php endif; ?>" required>
    </label> <input type="submit" name="btnFactura" value="Borrar">
   </form>

  </article>

  <article>

   <h3 class="text-center">Editar factura</h3>

   <form action="/facturas/editar" method="post">
    <?php echo csrf_field(); ?>
    <label for=""> <span>*ID:</span> <input class="text-end" type="number"
     name="id" id="id" value="<?php if(isset($factura)): ?><?php echo e($factura->id); ?><?php endif; ?>" required>
    </label> <label for=""> <span>*Fecha:</span> <input type="date"
     name="fecha" id="fecha" value="<?php if(isset($factura)): ?><?php echo e(explode(' ', $factura->fecha)[0]); ?><?php endif; ?>">
    </label> <label for=""> <span>Coste:</span> <input type="number" step="0.01"
     name="coste" id="coste" value="<?php if(isset($factura)): ?><?php echo e($factura->coste); ?><?php endif; ?>">
    </label> <label for=""> <span>*Detalles:</span>
    <textarea name="detalles" id="detalles"><?php if(isset($factura)): ?><?php echo e($factura->detalles); ?><?php endif; ?></textarea></label>

    <input type="submit" name="btnFactura" id="btnFactura" value="Editar">
   </form>

  </article>

  <article>

   <h3 class="text-center">Mostrar factura</h3>

   <form action="/facturas/mostrar" method="post">
    <?php echo csrf_field(); ?>
    <label for=""> <span>*ID:</span> <input class="text-end" type="number"
     name="id" id="id" value="<?php if(isset($factura)): ?><?php echo e($factura->id); ?><?php endif; ?>" required>
    </label> <input type="submit" name="btnFactura" value="Mostrar">

   </form>

   <h3 class="text-center">Mostrar listado</h3>

   <form action="/facturas/mostrar-todas" method="post">
    <?php echo csrf_field(); ?>
    <input type="submit" name="btnFactura"
     value="Mostrar todas">

   </form>

  </article>

 </div>

 <div class="container">

  <table class="table">

   <caption>Facturas</caption>

   <thead>
    <tr>
     <th>ID</th>
     <th>Fecha</th>
     <th>Coste</th>
     <th>Detalles</th>
     <th></th>
    </tr>
   </thead>

   <tbody>
    <?php if(isset($facturas)): ?>
        <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td data-label="ID"><?php echo e($factura->id); ?></td>
        <td data-label="FECHA"><?php echo e($factura->fecha); ?></td>
        <td data-label="COSTE"><?php echo e($factura->coste); ?></td>
        <td data-label="DETALLES"><?php echo e($factura->detalles); ?></td>
        <td>
        <a href="/facturas/opciones?id=<?php echo e($factura->id); ?>">
            Opciones
        </a>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
   </tbody>

  </table>
 </div>


</body>

</html>
<?php /**PATH /home/chris/Dev/TCnovRaulChristian/php/veterinariaphp/resources/views/facturas.blade.php ENDPATH**/ ?>