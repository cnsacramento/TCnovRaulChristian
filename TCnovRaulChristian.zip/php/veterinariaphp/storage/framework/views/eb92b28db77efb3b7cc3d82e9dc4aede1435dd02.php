<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
<title>Veterinario</title>
	<link rel='stylesheet' type='text/css' media='screen' href="<?php echo e(asset('css/general.css')); ?>">
    <link rel='stylesheet' type='text/css' media='screen' href="<?php echo e(asset('css/mascotas.css')); ?>">
</head>
<body>
	<header>
	  	<nav>
		  <a href="/" class="nav-link">Volver</a>
        </nav>
	</header>
	
		<!-- VETERINARIO -->    	
	
	<div class ="contenedor">	
		<?php if(empty($especialidad)): ?>
			<?php if(empty($especialidadAsignada) && empty($veterinario)): ?>
			    <div class = "formularios">    
				    <div class="container">
				    	<form action="/veterinario/crearVeterinario" method="POST">
						<?php echo csrf_field(); ?>
				    		<a href="#tableEspecialidades">
					    		<input class="controls" type="text" name="dni" value="" placeholder="DNI" readonly="readonly"> 
								<input class="controls" type="text" name="nombre" value="" placeholder="Nombre" readonly="readonly"> 
								<input class="controls" type="text" name="apellidos" value="" placeholder="Apellidos" readonly="readonly"> 
								<input class="controls" type="text" name="telefono" value="" placeholder="Telefono" readonly="readonly"> 
								<input class="controls" type="text" name="especialidad" value="<?php echo e($especialidadAsignada); ?>" placeholder="seleccione una especialidad" required="required" readonly="readonly"> 
								<input class="controls" type="text" name="correo" value="" placeholder="Correo">   
	        					<input class="controls" type="password" name="contrasenia" value="" placeholder="Contraseña">
								<input class="buttons" type="submit" name="boton" value="Crear Veterinario">
							</a>
						</form><br>
				    </div>
			    </div>
			<?php endif; ?>	
			<?php if(!empty($especialidadAsignada)): ?>
			    <div class = "formularios">    
				    <div class="container">
				    	<form action="/veterinario/crearVeterinario" method="POST">
							<?php echo csrf_field(); ?>
				    		<input class="controls" type="text" name="dni" value="" placeholder="DNI" pattern="[0-9]{7,8}[A-Za-z]"> 
							<input class="controls" type="text" name="nombre" value="" placeholder="Nombre"> 
							<input class="controls" type="text" name="apellidos" value="" placeholder="Apellidos"> 
							<input class="controls" type="text" name="telefono" value="" placeholder="Telefono"> 
							<a href="#tableEspecialidades">
								<input class="controls" type="text" name="especialidad" value="<?php echo e($especialidadAsignada); ?>" placeholder="seleccione una especialidad" required="required" readonly="readonly"> 
							</a>
							<input class="controls" type="text" name="correo" value="" placeholder="Correo">   
        					<input class="controls" type="password" name="contrasenia" value="" placeholder="Contraseña">
							<input class="buttons" type="submit" name="boton" value="Crear Veterinario">
						</form><br>
				    </div>
			    </div>
	   		<?php endif; ?>
	   		 
	   		<?php if(!empty($veterinario)): ?>
			    <div class = "formularios">    
				    <div class="container">
				    	<form action="/veterinario/editarVeterinario" method="POST">
							<?php echo csrf_field(); ?>
				    		<input class="controls" type="text" name="dni" value="<?php echo e($veterinario->dni); ?>" placeholder="DNI" pattern="[0-9]{7,8}[A-Za-z]" readonly="readonly"> 
							<input class="controls" type="text" name="nombre" value="<?php echo e($veterinario->nombre); ?>" placeholder="Nombre"> 
							<input class="controls" type="text" name="apellidos" value="<?php echo e($veterinario->apellidos); ?>" placeholder="Apellidos"> 
							<input class="controls" type="text" name="telefono" value="<?php echo e($veterinario->telefono); ?>" placeholder="Telefono"> 
							<input class="controls" type="text" name="especialidad" value="<?php echo e($veterinario->especialidadVeterinario->id); ?>" placeholder="seleccione una especialidad" required="required"> 
							<input class="buttons" type="submit" name="boton" value="Actualizar Veterinario">
						</form><br>
				    </div>
			    </div>
	   		<?php endif; ?>
	   		 
			<div class ="container">
			<div class ="container">
				<form action="/veterinario/findByName" method="POST">
					<?php echo csrf_field(); ?>
					<label for ="nombre"> </label> 
					<input class="controls" type="text" name="nombre" value="" placeholder="Nombre"> 
					<input class="buttons" type="submit" name="boton" value="Encontrar">
				</form><br>
			</div>
			<div class="container">
				<div class="wrapper">
			        <table class="table">
			            <caption>Veterinarios:</caption>
			            <thead>
			                <tr>
			                    <th>DNI</th>
			                    <th>Nombre</th>
			                    <th>Apellidos</th>
								<th>Telefono</th>
                			    <th>Especialidad</th>
			                    <th></th>
			                </tr>
			            </thead>
			            <tbody>
							<?php $__currentLoopData = $veterinarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veterinario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
				                    <td data-label="Dni"><?php echo e($veterinario->dni); ?></td>
				                    <td data-label="Nombre"><?php echo e($veterinario->nombre); ?></td>
				                    <td data-label="Apellidos"><?php echo e($veterinario->apellidos); ?></td>
									<td data-label="Telefono"><?php echo e($veterinario->telefono); ?></td>
				                    <td data-label="Peligrosa"><?php echo e($veterinario->especialidadVeterinario->nombre); ?></td>
				                    <td data-label="Opciones">
										<div class="imagenes">
											<a href="/veterinario/editarVeterinario?dni=<?php echo e($veterinario->dni); ?>" id="btnOpciones"><img alt="editEspecie" src="<?php echo e(asset('images/edit.svg')); ?>"></a>
											<a href="/veterinario/borrarVeterinario?dni=<?php echo e($veterinario->dni); ?>" id="btnOpciones"><img alt="deleteEspecie" src="<?php echo e(asset('images/delete.svg')); ?>"></a>
										</div>
									</td>
			                	</tr>
			            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            </tbody>
			        </table>
			    </div>
			</div>	
		</div>
		<?php endif; ?>
	</div>
	<!-- Especialidad -->    
	
	
	<div class ="contenedor">			
			<?php if(empty($especialidad)): ?>
				<div class = "formularios">    
				    <div class="container">
				    	<form action="/veterinario/crearEspecialidad" method="POST">
							<?php echo csrf_field(); ?>
							<input class="controls" type="text" name="nombre" value="" placeholder="Nombre"> 
							<input class="buttons" type="submit" name="boton" value="Crear Especialidad">
						</form>
				    </div>
			    </div>
			<?php endif; ?>
			<?php if(!empty($especialidad)): ?>
				<div class = "formularios">    
				    <div class="container">
				    	<form action="/veterinario/editarEspecialidad" method="POST">
							<?php echo csrf_field(); ?>
							<input class="controls" type="text" name="id" value="<?php echo e($especialidad->id); ?>" placeholder="Nombre" readonly="readonly"> 
							<input class="controls" type="text" name="nombre" value="<?php echo e($especialidad->nombre); ?>" placeholder="Nombre"> 
							<input class="buttons" type="submit" name="boton" value="Editar Especialidad">
						</form>
				    </div>
				</div>
			<?php endif; ?>
   		 <div class ="container">
	
		<div class="container">
			<div class="wrapper">
			        <table class="table" id="tableEspecialidades">
			            <caption>Seleccione la especialidad:</caption>
			            <thead>
			                <tr>
			                    <th>ID</th>
			                    <th>Nombre</th>
			                    <th></th>
			                </tr>
			            </thead>
			            <tbody>
							<?php $__currentLoopData = $especialidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $especialidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
				                    <td data-label="ID"><?php echo e($especialidad->id); ?></td>
				                    <td data-label="Nombre"><?php echo e($especialidad->nombre); ?></td>
				                    <td data-label="Opciones">
										<div class="imagenes">
											<a href="/veterinario/editarEspecialidad?&especialidad=<?php echo e($especialidad->id); ?>" id="btnOpciones"><img alt="editEspecie" src="<?php echo e(asset('images/edit.svg')); ?>"></a>
											<a href="/veterinario/borrarEspecialidad?&especialidad=<?php echo e($especialidad->id); ?>" id="btnOpciones"><img alt="deleteEspecie" src="<?php echo e(asset('images/delete.svg')); ?>"></a>
											<a href="/veterinario/asignarEspecialidad?&especialidad=<?php echo e($especialidad->id); ?>" id="btnOpciones"><img alt="deleteEspecie" src="<?php echo e(asset('images/intervencion.svg')); ?>"></a>
										</div>
									</td>
			                	</tr>
			            	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			            </tbody>
			        </table>
	    	</div>
	    </div>
	</div>
	</div>		
</body>
</html><?php /**PATH /home/chris/Dev/TCnovRaulChristian/php/veterinariaphp/resources/views/veterinario.blade.php ENDPATH**/ ?>