<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear intervención</title>
    <link rel='stylesheet' type='text/css' media='screen' href='<?php echo e(asset('css/general.css')); ?>'>
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/crud.css')); ?>">
    <meta name="description" content="Creacíon de la intervención">
</head>

<body>

	<div class="crud">

		<div class="column">

			<?php if(!$bloqueos["bloqueoFecha"]): ?>
				<article>

					<h3 class="text-center">Escoge la fecha</h3>

					<form action="/intervenciones/crear" method="post">
                        <?php echo csrf_field(); ?>
						<input type="date" name="fecha" value="<?php if(isset($fecha)): ?><?php echo e($fecha); ?><?php endif; ?>"
							min="<?php echo e(date("Y-m-d")); ?>"
							required> <input type="submit" name="fechaIntervencion"
							value="Escoger fecha">

					</form>

				</article>
			<?php endif; ?>

			<?php if(!$bloqueos["bloqueoHora"]): ?>
				<article>

					<h3 class="text-center">Escoge la hora</h3>

					<form action="/intervenciones/crear" method="post">
                        <?php echo csrf_field(); ?>
						<div class="selectform">
							<label for=""> <span>Horas disponibles</span></label> <select
								name="hora">
								<?php $__currentLoopData = $horasLibres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hora): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($hora); ?>"><?php echo e($hora); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<input type="submit" name="fechaIntervencion" value="Escoger hora">
					</form>

				</article>
			<?php endif; ?>

			<?php if(!$bloqueos["bloqueoSesiones"]): ?>
				<article>

					<h3 class="text-center">Escoge la cantidad de sesiones</h3>

					<form action="/intervenciones/crear" method="post">
                        <?php echo csrf_field(); ?>
						<div class="selectform">
							<label for=""> <span>Sesiones disponibles</span></label> <select
								name="numeroSesiones">
								<?php $__currentLoopData = $sesionesDisponibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sesion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($sesion); ?>"><?php echo e($sesion); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<input type="submit" name="fechaIntervencion"
							value="Escoger sesiones">
					</form>

				</article>
			<?php endif; ?>


			<?php if(!$bloqueos["bloqueoDatos"]): ?>
                <article>

					<h3 class="text-center">Rellena los datos</h3>

					<form action="/intervenciones/crear" method="post">
                        <?php echo csrf_field(); ?>
						<label for=""> <span>*Asunto:</span> <input type="text"
							name="asunto" id="asunto" maxlength="30" required>
						</label> <label for=""> <span>*Descripción:</span> <textarea
								name="descripcion" id="descripcion" required></textarea>
						</label>

						<div class="selectform">
							<label for=""> <span>*Tipo intervención:</span></label> <select
								name="tipointervencion">
								<?php $__currentLoopData = $tiposIntervenciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoIntervencion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($tipoIntervencion->id); ?>"><?php echo e($tipoIntervencion->tipo); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
						</div>

						<label for=""> <span>*ID mascota:</span> <input
							type="number" name="idmascota" id="idmascota">
						</label> <label for=""> <span>*Equipo:</span> <input type="text"
							name="equipo" id="equipo" required>

						</label> <input type="submit" name="fechaIntervencion" value="Continuar">
					</form>

				</article>
			<?php endif; ?>


			<?php if(!$bloqueos["bloqueoFactura"]): ?>

				<article>

					<h3 class="text-center">Crear factura</h3>

					<form action="/intervenciones/crear" method="post">
                        <?php echo csrf_field(); ?>
						<label for=""> <span>*Fecha:</span> <input type="date" min="<?php echo e(date("Y-m-d")); ?>"
							name="fechafactura" id="fecha" value="<?php echo e(date("Y-m-d")); ?>">
						</label> <label for=""> <span>Coste:</span> <input
							class="text-end" type="number" step="0.01" name="coste"
							id="coste">
						</label> <label for=""> <span>*Detalles:</span> <textarea
								name="detalles" id="detalles"></textarea></label> <input type="submit"
							name="fechaIntervencion" id="fechaIntervencion"
							value="Crear factura">
					</form>

				</article>
			<?php endif; ?>

		</div>

	</div>
</body>

</html>
<?php /**PATH /home/chris/Dev/TCnovRaulChristian/php/veterinariaphp/resources/views/fechaIntervencion.blade.php ENDPATH**/ ?>