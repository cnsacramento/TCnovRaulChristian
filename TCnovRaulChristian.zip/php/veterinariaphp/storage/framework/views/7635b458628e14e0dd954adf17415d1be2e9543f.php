<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Intervención</title>
    <link rel='stylesheet' type='text/css' media='screen' href="<?php echo e(asset('css/general.css')); ?>">
    <link rel="stylesheet" type="text/css" media="screen" href="<?php echo e(asset('css/crud.css')); ?>">
    <meta name="description" content="Métodos para realizar el CRUD sobre intervención y tipos de intervenciones">
</head>

<body>
    <header>
        <nav>
            <a href="/" class="nav-link">Volver</a>
        </nav>
    </header>

    <div class="crud">

        <article>

            <h3 class="text-center">Crear intervención</h3>

            <form action="/intervenciones/crear" method="post">
                <?php echo csrf_field(); ?>
                <input type="submit" name="fechaIntervencion" value="Crear">
            </form>

            <h3 class="text-center">Editar intervención</h3>

            <form action="/intervenciones/editar-intervencion" method="post">
                <?php echo csrf_field(); ?>
                <label for=""> <span>*ID Intervención:</span> <input type="number" name="id"
                        id="id" value="<?php if(isset($intervencion)): ?><?php echo e($intervencion->id); ?><?php endif; ?>" required>
                </label> <label for=""> <span>*Asunto:</span> <input type="text" name="asunto"
                        id="asunto" maxlength="30" value="<?php if(isset($intervencion)): ?><?php echo e($intervencion->asunto); ?><?php endif; ?>" required>
                </label> <label for=""> <span>*Descripción:</span>
                    <textarea name="descripcion" id="descripcion">
                        <?php if(isset($intervencion)): ?> <?php echo e($intervencion->descripcion); ?><?php endif; ?>
                    </textarea>
                </label>

                <div class="selectform">
                    <label for=""> <span>*Tipo intervención:</span></label>
                    <select name="tipointervencion">
                        <?php $__currentLoopData = $tiposIntervenciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoIntervencion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tipoIntervencion->tipo); ?>"><?php echo e($tipoIntervencion->tipo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <label for=""> <span>*ID mascota:</span> <input type="number" name="idmascota" id="idmascota"
                        value="<?php if(isset($intervencion)): ?><?php echo e($intervencion->id_mascota); ?><?php endif; ?>">
                </label> <label for=""> <span>*ID factura:</span> <input type="text" name="factura"
                        id="factura" value="<?php if(isset($intervencion)): ?><?php echo e($intervencion->id_factura); ?><?php endif; ?>">
                </label>
                 <input type="submit" name="editar" id="editar" value="Editar">
            </form>

            <h3 class="text-center">Eliminar intervención</h3>
            <form action="/intervenciones/eliminar" method="post">
                <?php echo csrf_field(); ?>
                <label for=""> <span>*ID Intervención:</span> <input type="number" name="id"
                        id="id" value="<?php if(isset($intervencion)): ?><?php echo e($intervencion->id); ?><?php endif; ?>"
                        required>
                </label> <input type="submit" name="eliminar" value="Eliminar">
            </form>

            <h3 class="text-center">Mostrar Intervención</h3>

            <form action="/intervenciones/mostrar-intervencion" method="post">
                <?php echo csrf_field(); ?>
                <label for=""> <span>*ID:</span> <input type="number" name="id" id="id"
                        value="<?php if(isset($intervencion)): ?><?php echo e($intervencion->id); ?><?php endif; ?>" required>
                </label> <input type="submit" name="mostrar" value="Mostrar">

            </form>

            <h3 class="text-center">Mostrar listado</h3>

            <form action="/intervenciones/mostrar-intervenciones" method="post">
                <?php echo csrf_field(); ?>
                <input type="submit" name="mostrartodas" value="Mostrar todos">

            </form>

        </article>

        <article>

            <h3 class="text-center">Crear tipo intervención</h3>

            <form action="/intervenciones/crear-tipo" method="post">
                <?php echo csrf_field(); ?>
                <label for=""> <span>*Tipo:</span> <input type="text" name="tipo" id="tipo"
                        maxlength="30" required>
                </label> <input type="submit" name="btntipo" value="Crear">
            </form>

            <h3 class="text-center">Editar tipo intervención</h3>
            <form action="/intervenciones/editar-tipo" method="post">
                <?php echo csrf_field(); ?>
                <label for=""> <span>*ID Tipo Intervención:</span> <input type="number" name="id"
                        id="id" value="<?php if(isset($tipoIntervencionOpciones)): ?><?php echo e($tipoIntervencionOpciones->id); ?><?php endif; ?>"
                        required>
                </label> <label for=""> <span>*Tipo:</span>
                    <input type="text" value="<?php if(isset($tipoIntervencionOpciones)): ?><?php echo e($tipoIntervencionOpciones->tipo); ?><?php endif; ?>" name="tipo" id="tipo" maxlength="30" required>
                </label> <input type="submit" name="btntipo" value="Editar">
            </form>

            <h3 class="text-center">Eliminar tipo intervención</h3>
            <form action="/intervenciones/eliminar-tipo" method="post">
                <?php echo csrf_field(); ?>
                <label for=""> <span>*ID Tipo Intervención:</span> <input type="number" name="id"
                        id="id" value="<?php if(isset($tipoIntervencionOpciones)): ?><?php echo e($tipoIntervencionOpciones->id); ?><?php endif; ?>"
                        required>
                </label> <input type="submit" name="btntipo" value="Eliminar">
            </form>

            <h3 class="text-center">Mostrar tipo intervención</h3>

            <form action="/intervenciones/mostrar-tipo" method="post">
                <?php echo csrf_field(); ?>
                <label for=""> <span>*ID:</span> <input type="number" name="id" id="id"
                        value="<?php if(isset($tipoIntervencionOpciones)): ?><?php echo e($tipoIntervencionOpciones->id); ?><?php endif; ?>" required>
                </label> <input type="submit" name="btntipo" value="Mostrar">

            </form>

            <h3 class="text-center">Mostrar listado</h3>

            <form action="/intervenciones/mostrar-tipos" method="post">
                <?php echo csrf_field(); ?>
                <input type="submit" name="btntipo" value="Mostrar todos">

            </form>

        </article>

    </div>

    <div class="container">

        <table class="table">

            <caption>Intervenciones</caption>

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Asunto</th>
                    <th>Descripción</th>
                    <th>Tipo</th>
                    <th>Mascota</th>
                    <th>Factura</th>
                    <th>Equipo</th>
                    <th></th>
                </tr>
            </thead>

            <tbody>
                <?php if(isset($intervenciones)): ?>
                    <?php $__currentLoopData = $intervenciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $intervencion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($intervencion->id); ?></td>
                            <td data-label="Asunto"><?php echo e($intervencion->asunto); ?></td>
                            <td data-label="Descripcion"><?php echo e($intervencion->descripcion); ?></td>
                            <td data-label="Tipo"><?php echo e($intervencion->tipoIntervencion->tipo); ?></td>
                            <td data-label="Mascota"><?php echo e($intervencion->id_mascota); ?></td>
                            <td data-label="Factura"><?php echo e($intervencion->id_factura); ?></td>
                            <td data-label="Equipo">
                                <?php $__currentLoopData = $intervencion->veterinarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $veterinario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span><?php echo e($veterinario->dni); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td><a href="/intervenciones/opciones?id=<?php echo e($intervencion->id); ?>">Opciones
                                </a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>

        </table>
    </div>


    <div class="container">

        <table class="table">

            <caption>Tipo de intervenciones</caption>

            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tipo</th>
                    <th></th>
                </tr>
            </thead>

            <tbody>
                <?php if(isset($tiposIntervenciones)): ?>
                    <?php $__currentLoopData = $tiposIntervenciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoIntervencion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td data-label="ID"><?php echo e($tipoIntervencion->id); ?></td>
                            <td data-label="Tipo"><?php echo e($tipoIntervencion->tipo); ?></td>
                            <td><a href="/intervenciones/opciones-tipo?id=<?php if(isset($tipoIntervencion)): ?><?php echo e($tipoIntervencion->id); ?><?php endif; ?>">Opciones</a></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>

        </table>
    </div>

    <!--
    <c:if test="${not empty mensaje}">
        <script>
            alert("${mensaje}");
        </script>
    </c:if>
-->
</body>

</html>
<?php /**PATH /home/chris/Dev/TCnovRaulChristian/php/veterinariaphp/resources/views/intervenciones.blade.php ENDPATH**/ ?>